﻿namespace LinkService
{
    public class LinkDto
    {
        public string OriginalUrl { get; set; }
    }
}
